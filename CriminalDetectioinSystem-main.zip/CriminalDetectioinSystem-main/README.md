# CriminalDetectioinSystem
Dataset collecting , training the data and detecting the images.
The yml file uploaded is raw data so it cannot be seen unless you download it. 
The repo contains the UI part as well that we developed using python.
The whole structure of the project is the Dataset collector colects the data from the database and trainer code trains the data and create the model for the system. The detector file uses this model in real time environment.
